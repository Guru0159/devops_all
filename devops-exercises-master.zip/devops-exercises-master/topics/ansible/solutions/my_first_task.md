## My First Task - Solution

```
- name: Create a new directory
  file:
    path: "/tmp/new_directory"
    state: directory
```
