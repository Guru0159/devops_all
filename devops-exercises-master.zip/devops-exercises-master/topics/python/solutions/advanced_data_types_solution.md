## (Advanced) Identify the data type

For each of the following, identify what is the data type of the result variable

1. a = {'a', 'b', 'c'} -> set
2. b = {'1': '2'} -> dict
4. c = ([1, 2, 3]) -> list
4. d = (1, 2, 3) -> tuple
4. e = True+True -> int
