## Sum

### Objectives

1. Write a script that gets two numbers and prints their sum
3. Make sure the input is valid (= you got two numbers from the user)
2. Test the script by running and passing it two numbers as arguments 

### Constraints

1. Use functions
