## AWS - Budget Setup

### Objectives

Setup a cost budget in your AWS account based on your needs.
