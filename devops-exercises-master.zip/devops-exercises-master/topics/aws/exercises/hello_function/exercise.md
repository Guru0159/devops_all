# Hello Function

Create a basic AWS Lambda function that when given a name, will return "Hello <NAME>"

## Solution

Click [here](solution.md) to view the solution.