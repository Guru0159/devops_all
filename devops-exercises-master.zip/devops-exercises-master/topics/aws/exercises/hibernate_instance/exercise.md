## AWS EC2 - Hibernate an Instance

### Objectives

1. Create an instance that supports hibernation
2. Hibernate the instance
3. Start the instance
4. What way is there to prove that instance was hibernated from OS perspective?
