## "Killing" Containers

1. Run Pod with a web service (e.g. httpd)
2. Verify the web service is running with the `ps` command
3. Check how many restarts the pod has performed
4. Kill the web service process
5. Check how many restarts the pod has performed
6. Verify again the web service is running

## After you complete the exercise

* Why did the "RESTARTS" count raised?
