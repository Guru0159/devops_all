## Fork 102 - Solution

1. 4
2. 4
