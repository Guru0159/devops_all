
<summary>You have a colleague you don‘t get along with. Tell us some strategies how you create a good work relationship with them anyway.</summary><br><b>

Bad answer: I don't.
Better answer: Every person has strengths and weaknesses. This is true also for colleagues I don't have good work relationship with and this is what helps me to create good work relationship with them. If I am able to highlight or recognize their strengths I'm able to focus mainly on that when communicating with them.
</b></details>

<details>
<summary>What do you love about your work?</summary><br><b>

You know the best, but some ideas if you find it hard to express yourself:

* Diversity
* Complexity
* Challenging
* Communication with several different teams
</b></details>

<details>
<summary>What are your responsibilities in your current position?</summary><br><b>

You know the best :)
</b></details>


<summary>Why should we hire you for the role?</summary><br><b>

You can use and elaborate on one or all of the following:

* Passion
* Motivation 
* Autodidact
* Creativity (be able to support it with some actual examples)
</b></details>

## Questions you CAN ask

A list of questions you as a candidate can ask the interviewer during or after the interview.
These are only a suggestion, use them carefully. Not every interviewer will be able to answer these (or happy to) which should be perhaps a red flag warning for your regarding working in such place but that's really up to you.

<details>
<summary>What do you like about working here?</summary><br><b>
</b></details>

<details>
<summary>How does the company promote personal growth?</summary><br><b>
</b>

<details>
<summary>What is the current level of technical debt you are dealing with?</summary><br><b>

Be careful when asking this question - all companies, regardless of size, have some level of tech debt. 
Phrase the question in the light that all companies have the deal with this, but you want to see the current
pain points they are dealing with <br>

This is a great way to figure how managers deal with unplanned work, and how good they are at 
setting expectations with projects.
</b></details>